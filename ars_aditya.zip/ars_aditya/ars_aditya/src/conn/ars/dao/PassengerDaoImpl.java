package conn.ars.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import conn.ars.pojo.Passenger;
import conn.ars.utility.DBUtility;
import conn.ars.pojo.Passenger;

public class PassengerDaoImpl implements PassengerDao {
	String query;
	PreparedStatement ps;
	Connection conn;
	ResultSet rs;
	Passenger p = new Passenger();
	@Override
	public boolean addpass(Passenger p) {
		// TODO Auto-generated method stub
		query="insert into passenger1(passName, passNO, passAddress, passEmailId, passPassportno) values(?,?,?,?,?)";
		try
	    {
	    	 conn=DBUtility. establishConnection();
	    	ps=conn.prepareStatement(query);
	    	//ps.setInt(1,p.getPassId());
	    	ps.setString(1, p.getPassName());
	    	ps.setLong(2, p.getPassNo());
	    	ps.setString(3, p.getPassAddress());
	    	ps.setString(4, p.getPassEmailid());
	    	ps.setLong(5, p.getPassPassportno());
	    	//ps.setInt(6, p.getPassId());
	    	int row =ps.executeUpdate();
	    	if(row>0)
	    	{
	    	     return true;
	    	}
	    	else
	    	{
	    		return false;
	    	}
	    }
	    catch(ClassNotFoundException e)
	    {
	    	e.printStackTrace(); 
	    }
	    catch(SQLException e)
	    {
	    	e.printStackTrace();
	    }

		return true;
	}
		

	@Override
	public boolean updatepass(Passenger p) {
		// TODO Auto-generated method stub
		query = " update passenger1 set passName=?, passNO=?, passAddress=?, passEmailid=?, passPassportno=? where passId=?";
		try
	    {
	    	Connection conn=DBUtility. establishConnection();
	    	PreparedStatement ps=conn.prepareStatement(query);
	    	ps.setString(1, p.getPassName());
	    	ps.setLong(2, p.getPassNo());
	    	ps.setString(3, p.getPassAddress());
	    	ps.setString(4, p.getPassEmailid());
	    	ps.setLong(5,p.getPassPassportno());
	    	ps.setInt(6, p.getPassId());
	    	
	    	int row =ps.executeUpdate();
	    	if(row>0)
	    	{
	    	     return true;
	    	}
	    	else
	    	{
	    		return false;
	    	}
	    }
	    catch(ClassNotFoundException e)
	    {
	    	e.printStackTrace(); 
	    }
	    catch(SQLException e)
	    {
	    	e.printStackTrace();
	    }
		return true;
	}
	

	@Override
	public boolean deletepass(int passId) {
		// TODO Auto-generated method stub
		query = "delete from passenger1 where passId=?";
		try
	    {
	    	Connection conn=DBUtility. establishConnection();
	    	PreparedStatement ps=conn.prepareStatement(query);
	    	ps.setInt(1, passId);
	    	int row =ps.executeUpdate();
	    	if(row>0)
	    	{
	    	     return true;
	    	}
	    	else
	    	{
	    		return false;
	    	}
	    }
	    catch(ClassNotFoundException e)
	    {
	    	e.printStackTrace(); 
	    }
	    catch(SQLException e)
	    {
	    	e.printStackTrace();
	    }

		return true;
	}

	@Override
	public Passenger displaypassbyId(int passId) {
		// TODO Auto-generated method stub
		query="select * from passenger1 where passId=?";
		try
	    {
	    	Connection conn=DBUtility. establishConnection();
	    	PreparedStatement ps=conn.prepareStatement(query);
	    	ps.setInt(1,passId);
	    	ResultSet  rs = ps.executeQuery();
			while(rs.next())
			{
				p.setPassId(rs.getInt(1));
				p.setPassName(rs.getString(2));
				p.setPassNo(rs.getLong(3));
				p.setPassAddress(rs.getString(4));
				p.setPassEmailid(rs.getString(5));
				p.setPassPassportno(rs.getLong(6));
			}
	    }
		catch (ClassNotFoundException | SQLException e) 
		{
			e.printStackTrace();
		}
		return p;
	}

	@Override
	public List<Passenger> displayAllpass() {
		// TODO Auto-generated method stub
		query="select * from passenger1";
		 Connection conn;
			List<Passenger> PassengerList = new ArrayList<Passenger>();
			try 
			{
				conn = DBUtility. establishConnection();
				ps =  conn.prepareStatement(query);
				ResultSet  rs = ps.executeQuery();

				while(rs.next())
				{
					Passenger p = new Passenger();
					p.setPassId(rs.getInt(1));
					p.setPassName(rs.getString(2));
					p.setPassNo(rs.getLong(3));
					p.setPassAddress(rs.getString(4));
					p.setPassEmailid(rs.getString(5));
					p.setPassPassportno(rs.getLong(6));
					PassengerList.add(p);
				}
			}
			catch (ClassNotFoundException | SQLException e) 
			{
				e.printStackTrace();
			}
		return PassengerList;
	}

	
}
