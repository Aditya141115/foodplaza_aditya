package conn.ars.test;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import conn.ars.dao.PassengerDao;
import conn.ars.dao.PassengerDaoImpl;
import conn.ars.pojo.Passenger;
import conn.ars .pojo.Passenger;

public class PassengerTest 
{
public static void main(String[] args) {
	long passNo,passPassportno;
	int choice,passId;
	String passName,passEmailid,passAddress;
	 Passenger p = new Passenger();
	 PassengerDaoImpl pd = new  PassengerDaoImpl();
	 boolean flag;
	 Scanner sc = new Scanner(System.in);
	 do
		{
		
			System.out.println("1.Add Passenger\n2.Update Passenger\n3.Delete Passenger\n4.DisplaypassengerById\n5.DisplayAllpassenger\n6.Exit ");
			System.out.println("Enter Your Choice:");
		choice= sc.nextInt();
		switch (choice)
		
		{
		case 1:
			System.out.println("Enter Passenger Name: ");
			passName = sc.next();
			System.out.println("Enter Passenger Contact: ");
			passNo = sc.nextLong();
			System.out.println("Enter Passenger Address:");
			passAddress=sc.next();
			System.out.println("Enter Passenger EmailId:");
			passEmailid=sc.next();
			System.out.println("Enter Passport No:");
			passPassportno =sc.nextLong();
			p.setPassName(passName);
			p.setPassNo(passNo);
			p.setPassAddress(passAddress);
            p.setPassEmailid(passEmailid);
            p.setPassPassportno(passPassportno);
            flag = pd.addpass(p);
if(flag==true)
{
	System.out.println("Passenger Added...");
}
else
{
	System.out.println("Passenger Adding Failed...");
}
break;

		case 2:
			System.out.println("Enter the Passenger Id:");
			passId=sc.nextInt();
			System.out.println("Enter the Passenger name:");
			passName=sc.next();
			System.out.println("Enter the Passenger contact:");
		 passNo=sc.nextLong();
			System.out.println("Enter the Passenger address:");
			passAddress=sc.next();
			System.out.println("Enter the Passenger Emailid:");
			passEmailid=sc.next();
			System.out.println("Enter the Passenger Passport No:");
			passPassportno=sc.nextLong();
			p.setPassId(passId);
			p.setPassName(passName);
			p.setPassNo(passNo);
			p.setPassAddress(passAddress);
			p.setPassEmailid(passEmailid);
			p.setPassPassportno(passPassportno);;
			flag= pd.updatepass(p);
			if(flag==true)
			{
				System.out.println("Passenger update  successfully");
			}
			else
			{
				System.out.println("Passenger not Update successfully");
			}
			

			break;
		case 3:
			System.out.println("Enter the Passenger id");
			passId=sc.nextInt();
			p.setPassId(passId);
			flag=pd.deletepass(passId);
			if(flag==true)
			{
				System.out.println("Passenger Delete successfully");
			}
			else
			{
				System.out.println("Passenger Not Delete successfully");
			}

			break;	
		case 4:
			System.out.println("Enter the Passenger id");
			passId=sc.nextInt();
			p.setPassId(passId);
			p = pd.displaypassbyId(passId);
			System.out.println(p.getPassId()+" "+p.getPassName()+" "+p.getPassNo()+" "+p.getPassAddress()+" "+p.getPassEmailid()+" "+p.getPassPassportno());

			break;
		case 5:
			List<Passenger> p1 = new ArrayList<Passenger>();
			p1=pd.displayAllpass();
			for(Passenger passenger : p1)
			{
				System.out.println(passenger.getPassId()+" "+passenger.getPassName()+" "+passenger.getPassNo()+" "+passenger.getPassAddress()+" "+passenger.getPassEmailid()+" "+passenger.getPassPassportno());
			}
            break;
			
		case 6:
			System.out.println("Exit");

			break;	
		default:
			System.out.println("Enter the invalid choice[1-6]");
			break;
		}
		}while(choice<6);
}
}
