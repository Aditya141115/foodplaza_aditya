package conn.ars.pojo;

public class Passenger {
// passId, passName, passNO,passEmailid,passPasspoetno

	private long passNo,passPassportno;
	private int passId;
	private String passName,passEmailid,passAddress;
	public long getPassNo() {
		return passNo;
	}
	public void setPassNo(long passNo) {
		this.passNo = passNo;
	}
	public long getPassPassportno() {
		return passPassportno;
	}
	public void setPassPassportno(long passPassportno) {
		this.passPassportno = passPassportno;
	}
	public int getPassId() {
		return passId;
	}
	public void setPassId(int passId) {
		this.passId = passId;
	}
	public String getPassName() {
		return passName;
	}
	public void setPassName(String passName) {
		this.passName = passName;
	}
	public String getPassEmailid() {
		return passEmailid;
	}
	public void setPassEmailid(String passEmailid) {
		this.passEmailid = passEmailid;
	}
	
	public String getPassAddress() {
		return passAddress;
	}
	public void setPassAddress(String passAddress) {
		this.passAddress = passAddress;
	}
	
}
