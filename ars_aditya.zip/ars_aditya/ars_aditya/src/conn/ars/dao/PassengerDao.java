package conn.ars.dao;
import java.util.List;

import conn.ars.pojo.*;
import conn.ars.pojo.Passenger;
public interface PassengerDao {
//add,delete,update,show01,diplayall
	boolean addpass(Passenger p);
	boolean deletepass(int passId);
	boolean updatepass(Passenger p);
	Passenger displaypassbyId (int passId);
	List<Passenger>displayAllpass();
	
	
}
